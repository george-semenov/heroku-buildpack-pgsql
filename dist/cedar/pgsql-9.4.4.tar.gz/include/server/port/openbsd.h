/* src/include/port/openbsd.h */
